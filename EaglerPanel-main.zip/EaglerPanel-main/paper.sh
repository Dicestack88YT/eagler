cd server && java -Xms8192M -Xmx8192M -jar server.jar
