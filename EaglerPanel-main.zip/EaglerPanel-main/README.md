<h1 align="center">EaglerPanel</h1>
<p align="center"><i>Please credit me for this.</i></p>
<br>
<p align="center"><i>And subscribe to IsmaelTech <a href="https://www.youtube.com/channel/UCwSd8pbURlMBAIxqq8EaELw?sub_confirmation=1">Fr</a></i></p>
<br>
<h1 align="center">The panel works with console, minecraft 1.17.1, waterfall 1.20 #562</h1>
<p align="center"><i>Maybe soon a ngrok or cloudflare tunnels.</i></p>
<br>
<h1> Renember to use this commands!!! </h1>
<p>chmod +x install.sh</p>
<p>./install.sh</p>
<p>sdk install java 17.0.9-amzn</p>
<p>write "y", without ", and MAKE SURE TO WRITE y</p>
<p>enter, and wait it to finish and do the folowing commands</p>
<p>chmod +x paper.sh</p>
<p>./paper.sh</p>
<p>Create another tab and chmod +x waterfall.sh</p>
<p>./waterfall.sh</p>
<br>
<h2> Renember to use chmod +x name.sh </h2>
<h2> Change the "name.sh" according to the files ^ above </h2>
<p>To start the script</p>
